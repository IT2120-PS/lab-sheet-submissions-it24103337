setwd("C://Users//it24103337//Desktop//P&S")

branch_data <- read.table("Exercise.txt", header=TRUE, sep=",")

str(branch_data)

boxplot(branch_data$Sales_X1, main="Boxplot - Sales", col="lightblue")

summary(branch_data$Advertising_X2)

find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lower <- q1 - 1.5 * iqr
  upper <- q3 + 1.5 * iqr
  x[x < lower | x > upper]
}

find_outliers(branch_data$Years_X3)